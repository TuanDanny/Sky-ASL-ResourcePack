#version 330

// Sky-ASL Liquid Glass (Frosted Crystal HUD) Shader Prototype
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec4 screenPos;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }

    // Nhan dien nen Scoreboard ben phai man hinh:
    // Minecraft mac dinh: Title = 0x40000000 (Alpha ≈ 0.25098), Lines = 0x30000000 (Alpha ≈ 0.18824)
    vec2 ndc = screenPos.xy / max(screenPos.w, 0.0001);
    bool isRightSide = (ndc.x > 0.0) || (gl_FragCoord.x > 350.0);
    bool isScoreboardBlack = (color.r == 0.0 && color.g == 0.0 && color.b == 0.0 && color.a >= 0.12 && color.a <= 0.35);

    if (isRightSide && isScoreboardBlack) {
        // Phan biet Header (Tieu de) va Body (Cac dong thong so)
        bool isHeader = (abs(color.a - 0.25098) < 0.035) || (color.a > 0.22);

        // Thiet ke Liquid Glass / Frosted Crystal (Kinh Long Pha Le):
        // Header: Mau sapphire deep cyan noi bat, sang hon
        // Body: Mau kinh pha le khoi xam xanh tram sang trong, do mo cao de ngam phong canh
        vec3 glassBase = isHeader ? vec3(0.06, 0.14, 0.26) : vec3(0.03, 0.07, 0.14);
        float glassAlpha = isHeader ? 0.40 : 0.26;

        // Hieu ung gradient doc mo nhe (Subtle vertical lighting)
        float vGradient = clamp((ndc.y + 0.6) * 0.5, 0.0, 1.0);
        glassBase += vec3(0.02, 0.04, 0.07) * vGradient;

        color = vec4(glassBase, glassAlpha);
    }

    fragColor = color * ColorModulator;
}
